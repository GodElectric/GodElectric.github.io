This is a resourcepack made by Zombie1111 for my maps. You are allowed to use this in your own projects if you credit me!
Thanks for downloading and using our content :D